create database Vtas5A;
use Vtas5A;

create table ventas (
codigo integer auto_increment primary key,
codigoCliente integer not null,
codigoComercial integer not null,
importeventa decimal (9.2),
importeComision decimal (9.2)
) engine = innodb;

delimiter // 
create procedure pr_calculo_comision (importe decimal (9.2)) 
begin 
set @var_global_comision := importe / 5;
end;
//
delimiter ;

delimiter //
create trigger actualizar_comision before insert on ventas for each row 
begin 
call pr_calculo_comision (NEW.importeventa); 
	set new.importeComision=@var_global_comision; 
end; 
//
delimiter ;

Insert into ventas (codigoCliente, codigoComercial, importeventa) values 
(100,10,15320.78);

Insert into ventas (codigoCliente, codigoComercial, importeventa) values 
(101,3,22000);

delimiter //
create procedure InsertaVentas (IN codigoCli int, IN codigoCom int, IN importev decimal (9.2)) 
begin 
insert into ventas (codigoCliente, codigoComercial, importeventa) values (codigoCli,codigoCom,importev); 
end; 
//
delimiter ;


