package BaseDatos;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import com.mysql.jdbc.Statement;
import BaseDatos.Altas.*;
import BaseDatos.Ver.*;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.Toolkit;


public class MuseoBD extends JFrame {
	JDesktopPane principal;
	static boolean admin = false;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MuseoBD frame = new MuseoBD();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	protected static void isAdmin() {
		try {

			Conexion conn = new Conexion();
			Connection con = Conexion.getConection();
			Statement st = (Statement) con.createStatement();
			
			String sql="Insert into adminTest values (1)";
			st.execute(sql);
			
			admin=true;
			System.err.println(admin);
			
		} catch (Exception e) {
			admin=false;
			System.err.println(admin);
		}

	}

	/**
	 * Create the frame.
	 */
	public MuseoBD() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(MuseoBD.class.getResource("/Images/mapaches.png")));
		isAdmin();
		MuseoBD t = this;
		setTitle("Museo Base De Datos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(10, 10, 1138, 753);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu Database = new JMenu("Database");
		menuBar.add(Database);
		
		JMenuItem Respaldar = new JMenuItem("Respaldar");
		Respaldar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Respaldo ventanaInterna= new Respaldo("Artistas", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		Database.add(Respaldar);
		
		JMenuItem Recuperacion = new JMenuItem("Recuperacion");
		Recuperacion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Recuperar ventanaInterna= new Recuperar("Artistas", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		Database.add(Recuperacion);
		
		JMenu Altas = new JMenu();
		Altas.setText("Objeto de Artes");
		menuBar.add(Altas);
		
		JMenuItem mntmAltaArtista = new JMenuItem("Artista");
		mntmAltaArtista.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AltaArtista ventanaInterna= new AltaArtista("Artistas", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		
		JMenuItem mntmObjetoDeArte = new JMenuItem("Objeto de Arte");
		mntmObjetoDeArte.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Altaobjeto_arte ventanaInterna= new Altaobjeto_arte("Objeto de Arte", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		Altas.add(mntmObjetoDeArte);
		mntmAltaArtista.setEnabled(true);
		Altas.add(mntmAltaArtista);
		
		JMenuItem mntmPintura = new JMenuItem("Pintura");
		mntmPintura.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AltaPintura ventanaInterna= new AltaPintura("Pintura", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		Altas.add(mntmPintura);
		
		JMenuItem mntmEscultura = new JMenuItem("Escultura");
		mntmEscultura.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AltaEscultura ventanaInterna= new AltaEscultura("Escultura", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		Altas.add(mntmEscultura);
		
		JMenuItem mntmEstatua = new JMenuItem("Estatua");
		mntmEstatua.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AltaEstatua ventanaInterna= new AltaEstatua("Estatua", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		Altas.add(mntmEstatua);
		
		JMenuItem mntmOtro = new JMenuItem("Otro");
		mntmOtro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AltaOtro ventanaInterna= new AltaOtro("Otro", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		Altas.add(mntmOtro);
		
		JMenu mnColeccion = new JMenu("Coleccion");
		menuBar.add(mnColeccion);
		
		JMenuItem mntmPermanente = new JMenuItem("Permanente");
		mntmPermanente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AltaCol_permanente ventanaInterna= new AltaCol_permanente("Permanente", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		mnColeccion.add(mntmPermanente);
		
		JMenuItem mntmPrestado = new JMenuItem("Prestado");
		mntmPrestado.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AltaCol_prestamo ventanaInterna= new AltaCol_prestamo("Prestado", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		mnColeccion.add(mntmPrestado);
		
		JMenu mnExhibicion = new JMenu("Exhibicion");
		menuBar.add(mnExhibicion);
		
		JMenuItem mntmAltaYBaja = new JMenuItem("Alta y Baja");
		mntmAltaYBaja.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AltaExhibicion ventanaInterna= new AltaExhibicion("Exhibicion", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		mnExhibicion.add(mntmAltaYBaja);
		
		JMenuItem mntmConectarConObjeto = new JMenuItem("Conectar con Objeto de Arte");
		mntmConectarConObjeto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ObjArte_Exhib ventanaInterna= new ObjArte_Exhib("Conectar con Objeto de Arte", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		mnExhibicion.add(mntmConectarConObjeto);
		
		JMenu mnVerObjetosDe = new JMenu("Ver Objetos de Artes");
		menuBar.add(mnVerObjetosDe);
		
		JMenuItem mntmArtista = new JMenuItem("Artista");
		mntmArtista.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				VerArtista ventanaInterna= new VerArtista("Artista", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		
		JMenuItem mntmObjetoDeArte_1 = new JMenuItem("Objeto de Arte");
		mntmObjetoDeArte_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				VerObjeto_arte ventanaInterna= new VerObjeto_arte("Objeto de Arte", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		mnVerObjetosDe.add(mntmObjetoDeArte_1);
		mnVerObjetosDe.add(mntmArtista);
		
		JMenuItem mntmPintura_1 = new JMenuItem("Pintura");
		mntmPintura_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				VerPintura ventanaInterna= new VerPintura("Pintura", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		mnVerObjetosDe.add(mntmPintura_1);
		
		JMenuItem mntmEscultura_1 = new JMenuItem("Escultura");
		mntmEscultura_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				VerEscultura ventanaInterna= new VerEscultura("Escultura", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		mnVerObjetosDe.add(mntmEscultura_1);
		
		JMenuItem mntmEstatua_1 = new JMenuItem("Estatua");
		mntmEstatua_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				VerEstatua ventanaInterna= new VerEstatua("Estatua", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		mnVerObjetosDe.add(mntmEstatua_1);
		
		JMenuItem mntmOtro_1 = new JMenuItem("Otro");
		mntmOtro_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				VerOtro ventanaInterna= new VerOtro("Otro", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		mnVerObjetosDe.add(mntmOtro_1);
		
		JMenu mnColeccion_1 = new JMenu("Ver Coleccion");
		menuBar.add(mnColeccion_1);
		
		JMenuItem mntmPermanente_1 = new JMenuItem("Permanente");
		mntmPermanente_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				VerCol_permanente ventanaInterna= new VerCol_permanente("Permanente", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		mnColeccion_1.add(mntmPermanente_1);
		
		JMenuItem mntmPrestamo = new JMenuItem("Prestamo");
		mntmPrestamo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VerCol_prestamo ventanaInterna= new VerCol_prestamo("Prestado", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		mnColeccion_1.add(mntmPrestamo);
		
		JMenu mnVerExhibicion = new JMenu("Ver Exhibicion");
		menuBar.add(mnVerExhibicion);
		
		JMenuItem mntmExhibicion = new JMenuItem("Exhibicion");
		mntmExhibicion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				VerExhibicion ventanaInterna= new VerExhibicion("Prestado", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		mnVerExhibicion.add(mntmExhibicion);
		
		JMenuItem mntmObjetoDeArte_2 = new JMenuItem("Objeto de Arte y Exhibicion");
		mntmObjetoDeArte_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				VerObjart_exhib ventanaInterna= new VerObjart_exhib("Prestado", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		mnVerExhibicion.add(mntmObjetoDeArte_2);
		
		JMenu mnNewMenu = new JMenu("Bitacora");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Ver Bitacora");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				VerBitacora ventanaInterna= new VerBitacora("Prestado", true, true, true, t);
				principal.add(ventanaInterna);
				ventanaInterna.setVisible(true);
			}
		});
		mnNewMenu.add(mntmNewMenuItem);
		
		principal = new JDesktopPane();
		principal.setToolTipText("");
		principal.setBackground(new Color(0, 102, 102));
		setContentPane(principal);
		principal.setLayout(null);
		this.repaint();
		
		
		
	}
}


