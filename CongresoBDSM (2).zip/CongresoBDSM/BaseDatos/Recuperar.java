package BaseDatos;


import java.awt.Color;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JCheckBox;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;

import BaseDatos.Conexion;
import BaseDatos.MuseoBD;

import javax.swing.JTextField;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JRadioButton;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class Recuperar extends JInternalFrame {
	public MuseoBD principal;
	public JPanel contentPanel;
	Border border = BorderFactory.createLineBorder(Color.BLACK, 1);

	public Recuperar(String titulo, boolean tama�o, boolean cerrar, boolean maximizar, MuseoBD padre) {
		super(titulo, tama�o, cerrar, maximizar);
		getContentPane().setBackground(Color.DARK_GRAY);
		setVisible(true);
		principal = padre;
		contentPanel = (JPanel) this.getContentPane();
		contentPanel.setLayout(null);

		JLabel lblVerBitacora = new JLabel("Recuperar BD");
		lblVerBitacora.setForeground(Color.CYAN);
		lblVerBitacora.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 69));
		lblVerBitacora.setBounds(43, 13, 487, 84);
		getContentPane().add(lblVerBitacora);
		
		JLabel lblNewLabel = new JLabel("Desea Recuperar la base de datos?");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 35));
		lblNewLabel.setBounds(22, 110, 553, 76);
		getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Recuperar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String sql;
					//Para lo de SQL
					PreparedStatement ps = null;
					int rs=0;
					@SuppressWarnings("unused")
					Conexion conn = new Conexion();
					Connection con = Conexion.getConection();
					String[] tables= {"exhibicion","objeto_arte","Objart_exhib","artista","pintura","escultura",
							"estatua","otro","col_permanente","col_prestamo", "bitacora"};
					String[] tables2= {"exhibicion","Objart_exhib","objeto_arte"};
					
					for (String string : tables2) {
						sql="Delete from "+string+";";
						ps = (PreparedStatement) con.prepareStatement(sql);
						rs = ps.executeUpdate();
					}
					System.out.println("Yeet");
					for (int i = 0; i < tables.length; i++) {
						System.out.println(i);
						
						sql = "Insert into "+tables[i]+" SELECT * FROM respaldo_museo."+tables[i]+";";
						ps = (PreparedStatement) con.prepareStatement(sql);
						rs = ps.executeUpdate();
					}
					JOptionPane.showMessageDialog(null, "Base de datos Recuperado", "Done",
							JOptionPane.INFORMATION_MESSAGE);
				} catch (SQLException ex) {
					System.err.println(ex.toString());
				}
				
			}
		});
		btnNewButton.setBounds(247, 199, 97, 25);
		getContentPane().add(btnNewButton);

		setBounds(100, 100, 612, 301);

	}
}
