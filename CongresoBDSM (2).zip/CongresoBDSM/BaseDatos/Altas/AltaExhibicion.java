package BaseDatos.Altas;

import java.awt.Color;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import BaseDatos.Conexion;
import BaseDatos.MuseoBD;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class AltaExhibicion extends JInternalFrame{
	public MuseoBD principal;
	public JPanel contentPanel;
	private JTextField txtIdExb;
	private JTextField txtNombre;
	private JTextField txtFechaCom;
	private JTextField txtFechaFin;

	public AltaExhibicion(String titulo, boolean tama�o, boolean cerrar, boolean maximizar, MuseoBD padre) {
		super(titulo, tama�o, cerrar, maximizar);
		getContentPane().setBackground(Color.DARK_GRAY);
		setVisible(true);
		principal = padre;
		contentPanel = (JPanel) this.getContentPane();
		contentPanel.setLayout(null);
		
		JLabel lblExhibicion = new JLabel("Exhibicion");
		lblExhibicion.setForeground(Color.CYAN);
		lblExhibicion.setFont(new Font("Source Code Pro", Font.BOLD | Font.ITALIC, 62));
		lblExhibicion.setBounds(12, 13, 388, 66);
		getContentPane().add(lblExhibicion);
		
		JLabel lblIdExhibicion = new JLabel("id Exhibicion");
		lblIdExhibicion.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblIdExhibicion.setForeground(Color.WHITE);
		lblIdExhibicion.setBounds(12, 92, 167, 45);
		getContentPane().add(lblIdExhibicion);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNombre.setForeground(Color.WHITE);
		lblNombre.setBounds(367, 92, 105, 45);
		getContentPane().add(lblNombre);
		
		JLabel lblFechaComienzo = new JLabel("Fecha Comienzo");
		lblFechaComienzo.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblFechaComienzo.setForeground(Color.WHITE);
		lblFechaComienzo.setBounds(12, 145, 216, 45);
		getContentPane().add(lblFechaComienzo);
		
		JLabel lblFechaFinal = new JLabel("Fecha Final");
		lblFechaFinal.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblFechaFinal.setForeground(Color.WHITE);
		lblFechaFinal.setBounds(12, 191, 151, 45);
		getContentPane().add(lblFechaFinal);
		
		txtIdExb = new JTextField();
		txtIdExb.setColumns(10);
		txtIdExb.setBounds(191, 110, 164, 22);
		getContentPane().add(txtIdExb);
		
		txtNombre = new JTextField();
		txtNombre.setColumns(10);
		txtNombre.setBounds(484, 110, 164, 22);
		getContentPane().add(txtNombre);
		
		txtFechaCom = new JTextField();
		txtFechaCom.setColumns(10);
		txtFechaCom.setBounds(236, 163, 164, 22);
		getContentPane().add(txtFechaCom);
		
		txtFechaFin = new JTextField();
		txtFechaFin.setColumns(10);
		txtFechaFin.setBounds(236, 209, 164, 22);
		getContentPane().add(txtFechaFin);
		
		JButton btnAlta = new JButton("Alta");
		btnAlta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CallableStatement cs = null;
				//exhibicion values(IdExb,nombre,fecha_com,fecha_fin)
				//call InsertExhibicion
				try {
					Connection con = Conexion.getConection();
					cs = con.prepareCall("{call InsertExhibicion(?,?,?,?)}");
					cs.setString("IdExb",txtIdExb.getText());
					cs.setString("nombre",txtNombre.getText());
					cs.setString("fecha_com",txtFechaCom.getText());
					cs.setString("fecha_fin",txtFechaFin.getText());
					
					cs.execute();
					JOptionPane.showMessageDialog(null, "Exhibicion Ingresado");
					clearTxt();
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		});
		btnAlta.setBounds(442, 209, 97, 25);
		getContentPane().add(btnAlta);
		
		JButton btnBaja = new JButton("Baja");
		btnBaja.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CallableStatement cs = null;
				try {
					Connection con = Conexion.getConection();
					cs = con.prepareCall("delete from exhibicion where IdExb=?");
					cs.setString(1, txtIdExb.getText());
					
					cs.execute();
					JOptionPane.showMessageDialog(null, "Exhibicion Borrado Corectamente");
					clearTxt();
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		});
		btnBaja.setBounds(551, 209, 97, 25);
		getContentPane().add(btnBaja);

		setBounds(100, 100, 674, 278);

	}

	protected void clearTxt() {
		// TODO Auto-generated method stub
		txtIdExb.getText();   
		txtNombre.getText();  
		txtFechaCom.getText();
		txtFechaFin.getText();
	}
}
