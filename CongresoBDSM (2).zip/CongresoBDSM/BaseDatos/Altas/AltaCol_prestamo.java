package BaseDatos.Altas;

import java.awt.Color;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import BaseDatos.Conexion;
import BaseDatos.MuseoBD;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class AltaCol_prestamo extends JInternalFrame{
	public MuseoBD principal;
	public JPanel contentPanel;
	private JTextField txtIdObje;
	private JTextField txtInfo;
	private JTextField txtFechaDev;
	private JTextField txtFechaPrest;

	public AltaCol_prestamo(String titulo, boolean tama�o, boolean cerrar, boolean maximizar, MuseoBD padre) {
		super(titulo, tama�o, cerrar, maximizar);
		getContentPane().setBackground(Color.DARK_GRAY);
		setVisible(true);
		principal = padre;
		contentPanel = (JPanel) this.getContentPane();
		contentPanel.setLayout(null);
		
		JLabel lblColeccionPrestamo = new JLabel("Coleccion");
		lblColeccionPrestamo.setForeground(Color.WHITE);
		lblColeccionPrestamo.setFont(new Font("Source Code Pro", Font.BOLD | Font.ITALIC, 62));
		lblColeccionPrestamo.setBounds(0, 13, 350, 66);
		getContentPane().add(lblColeccionPrestamo);
		
		JLabel lblPrestamo = new JLabel("Prestado");
		lblPrestamo.setForeground(Color.CYAN);
		lblPrestamo.setFont(new Font("Source Code Pro", Font.BOLD | Font.ITALIC, 62));
		lblPrestamo.setBounds(63, 70, 350, 66);
		getContentPane().add(lblPrestamo);
		
		JLabel lblIdobje = new JLabel("idObjeto");
		lblIdobje.setForeground(Color.WHITE);
		lblIdobje.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblIdobje.setBounds(12, 149, 162, 49);
		getContentPane().add(lblIdobje);
		
		JLabel lblInformacion = new JLabel("informacion");
		lblInformacion.setForeground(Color.WHITE);
		lblInformacion.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblInformacion.setBounds(12, 209, 162, 49);
		getContentPane().add(lblInformacion);
		
		JLabel lblFechadevolucion = new JLabel("FechaDevolucion");
		lblFechadevolucion.setForeground(Color.WHITE);
		lblFechadevolucion.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblFechadevolucion.setBounds(12, 271, 260, 49);
		getContentPane().add(lblFechadevolucion);
		
		JLabel lblFechaPrestamo = new JLabel("Fecha Prestamo");
		lblFechaPrestamo.setForeground(Color.WHITE);
		lblFechaPrestamo.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblFechaPrestamo.setBounds(12, 321, 223, 49);
		getContentPane().add(lblFechaPrestamo);
		
		txtIdObje = new JTextField();
		txtIdObje.setColumns(10);
		txtIdObje.setBounds(249, 169, 164, 22);
		getContentPane().add(txtIdObje);
		
		txtInfo = new JTextField();
		txtInfo.setColumns(10);
		txtInfo.setBounds(249, 229, 164, 22);
		getContentPane().add(txtInfo);
		
		txtFechaDev = new JTextField();
		txtFechaDev.setColumns(10);
		txtFechaDev.setBounds(249, 291, 164, 22);
		getContentPane().add(txtFechaDev);
		
		txtFechaPrest = new JTextField();
		txtFechaPrest.setColumns(10);
		txtFechaPrest.setBounds(249, 341, 164, 22);
		getContentPane().add(txtFechaPrest);
		
		JButton btnAlta = new JButton("Alta");
		btnAlta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CallableStatement cs = null;
		//col_prestamo values (idObje,infor_col,fechaDev,fechaPrest);
				try {
					Connection con = Conexion.getConection();
					cs = con.prepareCall("{call Insertcol_prestamo(?,?,?,?)}");
					cs.setString("idObje",txtIdObje.getText());
					cs.setString("infor_col",txtInfo.getText());
					cs.setString("fechaDev",txtFechaDev.getText());
					cs.setString("fechaPrest",txtFechaPrest.getText());
					
					cs.execute();
					JOptionPane.showMessageDialog(null, "Coleccion Prestado Ingresado");
					clearTxt();
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		});
		btnAlta.setBounds(207, 383, 97, 25);
		getContentPane().add(btnAlta);
		
		JButton btnBaja = new JButton("Baja");
		btnBaja.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CallableStatement cs = null;
				try {
					Connection con = Conexion.getConection();
					cs = con.prepareCall("delete from col_prestamo where idObje=?");
					cs.setString(1, txtIdObje.getText());
					
					cs.execute();
					JOptionPane.showMessageDialog(null, "Coleccion Prestado Borrado Corectamente");
					clearTxt();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		});
		btnBaja.setBounds(316, 383, 97, 25);
		getContentPane().add(btnBaja);

		setBounds(100, 100, 461, 470);

	}

	protected void clearTxt() {
		txtIdObje.setText(null);    
		txtInfo.setText(null);      
		txtFechaDev.setText(null);  
		txtFechaPrest.setText(null);
		
		
	}
}
