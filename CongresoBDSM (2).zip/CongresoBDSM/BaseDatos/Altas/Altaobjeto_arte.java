package BaseDatos.Altas;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import BaseDatos.Conexion;
import BaseDatos.MuseoBD;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Altaobjeto_arte extends JInternalFrame {
	public MuseoBD principal;
	public JPanel contentPanel;
	private JTextField txtidObje;
	private JTextField idTitulo;
	private JTextField txtPais;
	private JTextField txtA�o;
	private JTextField txtEpoca;
	private JTextField txtDesc;

	public Altaobjeto_arte(String titulo, boolean tama�o, boolean cerrar, boolean maximizar, MuseoBD padre) {
		super(titulo, tama�o, cerrar, maximizar);
		getContentPane().setBackground(Color.DARK_GRAY);
		setVisible(true);
		principal = padre;
		contentPanel = (JPanel) this.getContentPane();
		contentPanel.setLayout(null);

		JLabel lblObjArte = new JLabel("Objeto de Arte");
		lblObjArte.setForeground(Color.CYAN);
		lblObjArte.setFont(new Font("Source Code Pro", Font.BOLD | Font.ITALIC, 62));
		lblObjArte.setBounds(12, 13, 534, 66);
		getContentPane().add(lblObjArte);

		JLabel lblIdobjeto = new JLabel("idObjeto");
		lblIdobjeto.setForeground(Color.WHITE);
		lblIdobjeto.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblIdobjeto.setBounds(12, 92, 128, 44);
		getContentPane().add(lblIdobjeto);

		JLabel lblPais = new JLabel("Pais");
		lblPais.setForeground(Color.WHITE);
		lblPais.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblPais.setBounds(12, 174, 128, 44);
		getContentPane().add(lblPais);

		JLabel lblAo = new JLabel("A\u00F1o");
		lblAo.setForeground(Color.WHITE);
		lblAo.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblAo.setBounds(309, 130, 62, 44);
		getContentPane().add(lblAo);

		JLabel lblTitulo = new JLabel("Titulo");
		lblTitulo.setForeground(Color.WHITE);
		lblTitulo.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblTitulo.setBounds(309, 92, 128, 44);
		getContentPane().add(lblTitulo);

		JLabel lblEpoca = new JLabel("Epoca");
		lblEpoca.setForeground(Color.WHITE);
		lblEpoca.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblEpoca.setBounds(12, 130, 128, 44);
		getContentPane().add(lblEpoca);

		JLabel lblDescripcion = new JLabel("Descripcion");
		lblDescripcion.setForeground(Color.WHITE);
		lblDescripcion.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblDescripcion.setBounds(12, 227, 161, 44);
		getContentPane().add(lblDescripcion);

		txtidObje = new JTextField();
		txtidObje.setColumns(10);
		txtidObje.setBounds(131, 110, 164, 22);
		getContentPane().add(txtidObje);

		idTitulo = new JTextField();
		idTitulo.setColumns(10);
		idTitulo.setBounds(393, 110, 164, 22);
		getContentPane().add(idTitulo);

		txtPais = new JTextField();
		txtPais.setColumns(10);
		txtPais.setBounds(131, 192, 164, 22);
		getContentPane().add(txtPais);

		txtA�o = new JTextField();
		txtA�o.setColumns(10);
		txtA�o.setBounds(393, 148, 164, 22);
		getContentPane().add(txtA�o);

		txtEpoca = new JTextField();
		txtEpoca.setColumns(10);
		txtEpoca.setBounds(131, 148, 164, 22);
		getContentPane().add(txtEpoca);

		txtDesc = new JTextField();
		txtDesc.setColumns(10);
		txtDesc.setBounds(170, 244, 387, 22);
		getContentPane().add(txtDesc);

		JButton btnBaja = new JButton("Baja");
		btnBaja.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CallableStatement cs = null;
				try {
					Connection con = Conexion.getConection();
					cs = con.prepareCall("delete from objeto_arte where idObje=?");
					cs.setString(1, txtidObje.getText());
					
					cs.execute();
					System.out.println("Test");
					JOptionPane.showMessageDialog(null, "Objeto de Arte Borrado Corectamente");
				} catch (SQLException e2) {
					e2.printStackTrace();
				}

			}
		});
		btnBaja.setBounds(460, 283, 97, 25);
		getContentPane().add(btnBaja);

		JButton btnAlta = new JButton("Alta");
		btnAlta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CallableStatement cs = null;
				/*
				 * IN IdObje integer, IN pais varchar(20), IN a�o date,IN titulo varchar(40),IN
				 * epoca varchar(20), IN descripcion varchar(500)
				 */
				// call InsertObjetoArte
				try {
					Connection con = Conexion.getConection();
					cs = con.prepareCall("{call InsertObjetoArte(?,?,?,?,?,?)}");
					cs.setString("IdObje", txtidObje.getText());
					cs.setString("pais", txtPais.getText());
					cs.setString("a�o", txtA�o.getText());
					cs.setString("titulo", txtPais.getText());
					cs.setString("epoca", txtEpoca.getText());
					cs.setString("descripcion", txtDesc.getText());

					cs.execute();
					JOptionPane.showMessageDialog(null, "Objeto de Arte Ingresado");

				} catch (SQLException e2) {
					e2.printStackTrace();
				}

			}
		});
		btnAlta.setBounds(351, 283, 97, 25);
		getContentPane().add(btnAlta);

		setBounds(100, 100, 588, 354);

	}
}
