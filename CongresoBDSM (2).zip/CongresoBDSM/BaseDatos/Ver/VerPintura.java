package BaseDatos.Ver;

import java.awt.Color;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import BaseDatos.Conexion;
import BaseDatos.MuseoBD;
import javax.swing.JTextField;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class VerPintura extends JInternalFrame {
	public MuseoBD principal;
	public JPanel contentPanel;
	private JTextField txtBuscar;
	private JTable table;
	Border border = BorderFactory.createLineBorder(Color.BLACK, 1);

	public VerPintura(String titulo, boolean tama�o, boolean cerrar, boolean maximizar, MuseoBD padre) {
		super(titulo, tama�o, cerrar, maximizar);
		getContentPane().setBackground(Color.DARK_GRAY);
		setVisible(true);
		principal = padre;
		contentPanel = (JPanel) this.getContentPane();
		contentPanel.setLayout(null);

		JLabel lblPinturas = new JLabel("Pinturas");
		lblPinturas.setForeground(Color.CYAN);
		lblPinturas.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 69));
		lblPinturas.setBounds(12, 13, 564, 84);
		getContentPane().add(lblPinturas);

		JLabel lblId = new JLabel("ID");
		lblId.setForeground(Color.WHITE);
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 29));
		lblId.setBounds(12, 99, 36, 45);
		getContentPane().add(lblId);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBorder(border);
		scrollPane.setBounds(12, 152, 772, 306);
		getContentPane().add(scrollPane);

		table = new JTable();
		table.setFont(new Font("Tahoma", Font.PLAIN, 18));
		scrollPane.setViewportView(table);

		txtBuscar = new JTextField();
		txtBuscar.setColumns(10);
		txtBuscar.setBounds(48, 117, 354, 22);
		getContentPane().add(txtBuscar);

		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Campo = txtBuscar.getText();
				String where = "";

				if (!"".equals(Campo)) {
					where = "WHERE idObje = '" + Campo + "'";
				}
				try {
					// New Table
					DefaultTableModel modelo = new DefaultTableModel();
					table.setModel(modelo);

					// Para lo de SQL
					PreparedStatement ps = null;
					ResultSet rs = null;
					@SuppressWarnings("unused")
					Conexion conn = new Conexion();
					Connection con = Conexion.getConection();

					String sql = "select idObje,tipo,estilo,material from pintura " + where;
					System.out.println(sql);

					ps = (PreparedStatement) con.prepareStatement(sql);
					rs = ps.executeQuery();

					java.sql.ResultSetMetaData rsMd = rs.getMetaData();
					int cantidadColumnas = rsMd.getColumnCount();

					// Para las columnas
					modelo.addColumn("idObje");
					modelo.addColumn("tipo");
					modelo.addColumn("estilo");
					modelo.addColumn("material");

					while (rs.next()) {
						Object[] filas = new Object[cantidadColumnas];
						for (int i = 0; i < cantidadColumnas; i++) {
							filas[i] = rs.getObject(i + 1);
						}
						modelo.addRow(filas);
					}
				} catch (SQLException ex) {
					System.err.println(ex.toString());
				}
				
			}
		});
		btnBuscar.setBounds(414, 116, 97, 25);
		getContentPane().add(btnBuscar);

		JButton btnActualizar = new JButton("Actualizar");
		btnActualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String where = "";
				try {
					// New Table
					DefaultTableModel modelo = new DefaultTableModel();
					table.setModel(modelo);

					// Para lo de SQL
					PreparedStatement ps = null;
					ResultSet rs = null;
					@SuppressWarnings("unused")
					Conexion conn = new Conexion();
					Connection con = Conexion.getConection();

					String sql = "select idObje,tipo,estilo,material from pintura " + where;
					System.out.println(sql);

					ps = (PreparedStatement) con.prepareStatement(sql);
					rs = ps.executeQuery();

					java.sql.ResultSetMetaData rsMd = rs.getMetaData();
					int cantidadColumnas = rsMd.getColumnCount();

					// Para las columnas
					modelo.addColumn("idObje");
					modelo.addColumn("tipo");
					modelo.addColumn("estilo");
					modelo.addColumn("material");

					while (rs.next()) {
						Object[] filas = new Object[cantidadColumnas];
						for (int i = 0; i < cantidadColumnas; i++) {
							filas[i] = rs.getObject(i + 1);
						}
						modelo.addRow(filas);
					}

				} catch (SQLException ex) {
					System.err.println(ex.toString());
				}
			}
		});
		btnActualizar.setBounds(523, 116, 97, 25);
		getContentPane().add(btnActualizar);

		setBounds(100, 100, 806, 501);

	}
}
