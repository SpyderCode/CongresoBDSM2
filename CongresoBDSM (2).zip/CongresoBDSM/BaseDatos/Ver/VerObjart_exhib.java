package BaseDatos.Ver;
import java.awt.Color;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import BaseDatos.Conexion;
import BaseDatos.MuseoBD;
import javax.swing.JTextField;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class VerObjart_exhib extends JInternalFrame{
	public MuseoBD principal;
	public JPanel contentPanel;
	private JTable table;
	Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
	private JTextField txtIdExb;
	private JTextField txtIdObje;

	public VerObjart_exhib(String titulo, boolean tama�o, boolean cerrar, boolean maximizar, MuseoBD padre) {
		super(titulo, tama�o, cerrar, maximizar);
		getContentPane().setBackground(Color.DARK_GRAY);
		setVisible(true);
		principal = padre;
		contentPanel = (JPanel) this.getContentPane();
		contentPanel.setLayout(null);
		
		JLabel lblExhibicionYObjetos = new JLabel("Exhibicion y Objetos");
		lblExhibicionYObjetos.setForeground(Color.CYAN);
		lblExhibicionYObjetos.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 69));
		lblExhibicionYObjetos.setBounds(12, 13, 721, 84);
		getContentPane().add(lblExhibicionYObjetos);
		
		JLabel lblIdexhibicion = new JLabel("IdExhibicion");
		lblIdexhibicion.setForeground(Color.WHITE);
		lblIdexhibicion.setFont(new Font("Tahoma", Font.PLAIN, 29));
		lblIdexhibicion.setBounds(12, 99, 159, 45);
		getContentPane().add(lblIdexhibicion);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBorder(border);
		scrollPane.setBounds(12, 211, 772, 306);
		getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Tahoma", Font.PLAIN, 18));
		scrollPane.setViewportView(table);
		
		txtIdExb = new JTextField();
		txtIdExb.setColumns(10);
		txtIdExb.setBounds(183, 110, 383, 22);
		getContentPane().add(txtIdExb);
		
		txtIdObje = new JTextField();
		txtIdObje.setColumns(10);
		txtIdObje.setBounds(183, 164, 383, 22);
		getContentPane().add(txtIdObje);
		
		JLabel lblIdobjetos = new JLabel("IdObjetos");
		lblIdobjetos.setForeground(Color.WHITE);
		lblIdobjetos.setFont(new Font("Tahoma", Font.PLAIN, 29));
		lblIdobjetos.setBounds(12, 153, 159, 45);
		getContentPane().add(lblIdobjetos);
		
		JButton btnBuscarExb = new JButton("Buscar");
		btnBuscarExb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Campo = txtIdExb.getText();
				String where = "";

				if (!"".equals(Campo)) {
					where = "WHERE idExb = '" + Campo + "'";
				}
				try {
					// New Table
					DefaultTableModel modelo = new DefaultTableModel();
					table.setModel(modelo);

					// Para lo de SQL
					PreparedStatement ps = null;
					ResultSet rs = null;
					@SuppressWarnings("unused")
					Conexion conn = new Conexion();
					Connection con = Conexion.getConection();

					String sql ="Select idObje,idExb from Objart_exhib "+where;
					System.out.println(sql);

					ps = (PreparedStatement) con.prepareStatement(sql);
					rs = ps.executeQuery();

					java.sql.ResultSetMetaData rsMd = rs.getMetaData();
					int cantidadColumnas = rsMd.getColumnCount();

					// Para las columnas
					modelo.addColumn("idObjeto");
					modelo.addColumn("idExhibicion");
					
					while (rs.next()) {
						Object[] filas = new Object[cantidadColumnas];
						for (int i = 0; i < cantidadColumnas; i++) {
							filas[i] = rs.getObject(i + 1);
						}
						modelo.addRow(filas);
					}

				} catch (SQLException ex) {
					System.err.println(ex.toString());
				}
			}
		});
		btnBuscarExb.setBounds(578, 110, 97, 25);
		getContentPane().add(btnBuscarExb);
		
		JButton btnBuscarObje = new JButton("Buscar");
		btnBuscarObje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Campo = txtIdObje.getText();
				String where = "";

				if (!"".equals(Campo)) {
					where = "WHERE idObje = '" + Campo + "'";
				}
				try {
					// New Table
					DefaultTableModel modelo = new DefaultTableModel();
					table.setModel(modelo);

					// Para lo de SQL
					PreparedStatement ps = null;
					ResultSet rs = null;
					@SuppressWarnings("unused")
					Conexion conn = new Conexion();
					Connection con = Conexion.getConection();

					String sql ="Select idObje,idExb from Objart_exhib "+where;
					System.out.println(sql);

					ps = (PreparedStatement) con.prepareStatement(sql);
					rs = ps.executeQuery();

					java.sql.ResultSetMetaData rsMd = rs.getMetaData();
					int cantidadColumnas = rsMd.getColumnCount();

					// Para las columnas
					modelo.addColumn("idObjeto");
					modelo.addColumn("idExhibicion");
					
					while (rs.next()) {
						Object[] filas = new Object[cantidadColumnas];
						for (int i = 0; i < cantidadColumnas; i++) {
							filas[i] = rs.getObject(i + 1);
						}
						modelo.addRow(filas);
					}

				} catch (SQLException ex) {
					System.err.println(ex.toString());
				}
			}
		});
		btnBuscarObje.setBounds(578, 164, 97, 25);
		getContentPane().add(btnBuscarObje);
		
		JButton btnActualizar = new JButton("Actualizar");
		btnActualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String where = "";
				try {
					// New Table
					DefaultTableModel modelo = new DefaultTableModel();
					table.setModel(modelo);

					// Para lo de SQL
					PreparedStatement ps = null;
					ResultSet rs = null;
					@SuppressWarnings("unused")
					Conexion conn = new Conexion();
					Connection con = Conexion.getConection();

					String sql ="Select idObje,idExb from Objart_exhib "+where;
					System.out.println(sql);

					ps = (PreparedStatement) con.prepareStatement(sql);
					rs = ps.executeQuery();

					java.sql.ResultSetMetaData rsMd = rs.getMetaData();
					int cantidadColumnas = rsMd.getColumnCount();

					// Para las columnas
					modelo.addColumn("idObjeto");
					modelo.addColumn("idExhibicion");
					
					while (rs.next()) {
						Object[] filas = new Object[cantidadColumnas];
						for (int i = 0; i < cantidadColumnas; i++) {
							filas[i] = rs.getObject(i + 1);
						}
						modelo.addRow(filas);
					}

				} catch (SQLException ex) {
					System.err.println(ex.toString());
				}
			}
		});
		btnActualizar.setBounds(687, 164, 97, 25);
		getContentPane().add(btnActualizar);

		setBounds(100, 100, 814, 566);

	}
}

